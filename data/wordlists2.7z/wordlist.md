# Make short wordlists from other wordlists:
Full pipeline for bilingual list 3/4:
```
rm /tmp/en_short.txt
rm /tmp/es_short.txt
# English (EFF diceware format: number<TAB>word)
awk '{print tolower($2)}' wordlist_en_eff.txt |
awk 'length($1) <= 4' > /tmp/en_short.txt

# Spanish (one word per line, strip accents)
iconv -f UTF-8 -t ASCII//TRANSLIT wordlist_es.txt |
awk '{print tolower($1)}' |
awk 'length($1) <= 4' > /tmp/es_short.txt

# Concatenate, deduplicate, final Keepassium list
cat /tmp/en_short.txt /tmp/es_short.txt |
sort -u > keepassium_en_es_3_4.txt
```
Full pipeline for bilingual list 3/4/5:
```
rm /tmp/en_short.txt
rm /tmp/es_short.txt
# English (EFF diceware format: number<TAB>word)
awk '{print tolower($2)}' wordlist_en_eff.txt |
awk 'length($1) <= 5' > /tmp/en_short.txt

# Spanish (one word per line, strip accents)
iconv -f UTF-8 -t ASCII//TRANSLIT wordlist_es.txt |
awk '{print tolower($1)}' |
awk 'length($1) <= 5' > /tmp/es_short.txt

# Concatenate, deduplicate, final Keepassium list
cat /tmp/en_short.txt /tmp/es_short.txt |
sort -u > keepassium_en_es_3_4_5.txt
```

# Manual parsing
```
awk '
{
    word = $2
    if (length(word) <= 4)
        print word
}
' wordlist_en_eff.txt > keepassium_en_3_4.txt
awk '
{
    word = $1
    if (length(word) <= 4)
        print word
}
' wordlist_es.txt > keepassium_es_3_4.txt
```
## Optional cleanup
Normalize and remove dupes:
```
sort -u keepassium_en_3_4.txt -o keepassium_en_3_4.txt
sort -u keepassium_es_3_4.txt -o keepassium_es_3_4.txt
```
