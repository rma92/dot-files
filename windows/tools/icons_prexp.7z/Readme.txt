Icons from 1990s Windows:
* cool: Cool.dll only
* NT4: Windows NT 4.0
* NT31: Windows NT 3.1 Workstation
* NT351: Windows NT 3.51 Workstation and Microsoft Office 97
* Plus98: Plus! 95, Plus! 98, Cool.dll
* win2k: Windows 2000 Professional (no updates or service pack, IE5)
* Win30mm-tandy: Windows 3.0 Multimedia Edition + Tandy demos
* Win31: Windows 3.1
* Win95: Windows 95
* Win98: Windows 98 and Plus
* Watcom: Watcom Compiler
* MSVC2: Visual C++ 2.0
* MSVC4: Visual C++ 4.0
* VS2003: Visual Studio 2003 (POST XP)
* MSO2000: Microsoft Office 2000
* MSO2003: Microsoft Office 2003 (POST XP)

The icons can be extracted using Nirsoft IconExtract (32-bit/64-bit EXE only) and BeCyIconGrabber, which also supports 16-bit binaries and can generate a 32-bit DLL that can then be extracted using IconExtract.
