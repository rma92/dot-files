Systemwide:
/usr/share/sounds/Chicago95/
Per user:
~/.local/share/sounds/Chicago95/
