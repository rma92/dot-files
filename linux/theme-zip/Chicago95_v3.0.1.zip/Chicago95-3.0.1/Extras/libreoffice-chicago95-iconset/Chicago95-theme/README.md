# README for Chicago95-theme LibreOffice icon set

## History
Unfortunately, I was unable to determine how to extract the toolbar icons from any of the dlls and exe files included in Office 95. The [tb97][2] reference includes some icons, but definitely not all.

## TODO
* make custom icons/chicago95-icon.png to match icons/office2013-icon.png

## References
[1]: https://winworldpc.com/product/microsoft-office/95 Office 95 Pro iso
[2]: https://jrsoftware.org/download.php/tb97.zip Some icons (MIT or BSD)
[3]: https://www.deviantart.com/charliecnr/art/Office-2013-theme-for-LibreOffice-512127527 Reference theme for what needs to be customized (LPGL)
[4]: https://1drv.ms/u/s!ArgKmgFcmBYHhSQkPfyMZRnXX5LJ Download link for [reference 3][3]
[5]: https://github.com/benwiley4000/win95-media-player media icons (MIT)
