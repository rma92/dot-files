## Examples:

Source: https://archive.org/details/blink18t
<p align="center">
<img src="demo_07.png" alt="Chicago95 Plus! Example"/>
</p>

Source: https://archive.org/details/american_202005
<p align="center">
<img src="demo_08.png" alt="Chicago95 Plus! Example"/>
</p>

Source: https://archive.org/details/dune2thm
<p align="center">
<img src="demo_09.png" alt="Chicago95 Plus! Example"/>
</p>

Source: https://archive.org/details/ra2theme
<p align="center">
<img src="demo_10.png" alt="Chicago95 Plus! Example"/>
</p>

Source: https://archive.org/details/hackerz_202005
<p align="center">
<img src="demo_11.png" alt="Chicago95 Plus! Example"/>
</p>

Source: https://archive.org/details/themes_dolphins_202005
<p align="center">
<img src="demo_12.png" alt="Chicago95 Plus! Example"/>
</p>