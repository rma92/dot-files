A Chicago95 Splash Screen.

