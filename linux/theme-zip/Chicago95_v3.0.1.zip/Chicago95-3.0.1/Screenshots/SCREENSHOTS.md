## Screenshots

#### Windows 95 Plymouth boot screen
![alt text](plymouth.gif "Windows95 Plymouth Boot Splash")

#### RetroTux Plymouth boot screen
![alt text](retrotux.png "RetroTux Plymouth Boot Splash")

#### Desktop screenshots
![alt text](Desktop0.png "Desktop")

![alt text](Desktop1.png "Desktop1")

![alt text](web_browser.png "Web Browser")

![alt text](Desktop2.png "Desktop2")

![alt text](Desktop3.png "Desktop3")

![alt text](Desktop4.png "Desktop4")

![alt text](Desktop5.png "Desktop5")

![alt text](Desktop6.png "Desktop6")

#### XFCE4 Screensaver lock screen
![alt text](lock_screen.png "Screensaver lock")

#### LightDM login manager theme
![alt text](lightdm_theme.png "LightDM")